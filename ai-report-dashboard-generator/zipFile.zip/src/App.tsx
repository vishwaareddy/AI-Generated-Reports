import { useState } from 'react';
import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import MobileNav from './components/MobileNav';
import UploadScreen from './screens/UploadScreen';
import AnalysisScreen from './screens/AnalysisScreen';
import DashboardScreen from './screens/DashboardScreen';
import ReportsScreen from './screens/ReportsScreen';
import PresentationsScreen from './screens/PresentationsScreen';
import InsightsScreen from './screens/InsightsScreen';
import ForecastingScreen from './screens/ForecastingScreen';
import ChatScreen from './screens/ChatScreen';

export type Screen = 'upload' | 'analysis' | 'dashboard' | 'reports' | 'presentations' | 'insights' | 'forecasting' | 'chat';

export default function App() {
  const [activeScreen, setActiveScreen] = useState<Screen>('upload');

  const goTo = (s: Screen) => setActiveScreen(s);

  const renderScreen = () => {
    switch (activeScreen) {
      case 'upload': return <UploadScreen onComplete={() => goTo('analysis')} />;
      case 'analysis': return <AnalysisScreen onComplete={() => goTo('dashboard')} />;
      case 'dashboard': return <DashboardScreen />;
      case 'reports': return <ReportsScreen />;
      case 'presentations': return <PresentationsScreen />;
      case 'insights': return <InsightsScreen />;
      case 'forecasting': return <ForecastingScreen />;
      case 'chat': return <ChatScreen />;
      default: return <DashboardScreen />;
    }
  };

  return (
    <div className="min-h-screen bg-[#030712] noise">
      {/* Ambient blobs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div
          className="absolute top-0 left-1/4 w-96 h-96 rounded-full opacity-[0.06] animate-blob"
          style={{ background: 'radial-gradient(circle, #6366f1, transparent)' }}
        ></div>
        <div
          className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full opacity-[0.05] animate-blob"
          style={{ background: 'radial-gradient(circle, #8b5cf6, transparent)', animationDelay: '3s' }}
        ></div>
        <div
          className="absolute top-1/2 left-1/2 w-64 h-64 rounded-full opacity-[0.04] animate-blob"
          style={{ background: 'radial-gradient(circle, #06b6d4, transparent)', animationDelay: '6s' }}
        ></div>
      </div>

      {/* Grid overlay */}
      <div className="fixed inset-0 grid-bg pointer-events-none z-0 opacity-60"></div>

      <div className="flex min-h-screen relative z-10">
        {/* Sidebar */}
        <Sidebar activeScreen={activeScreen} setActiveScreen={(s) => goTo(s as Screen)} />

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0">
          <TopBar activeScreen={activeScreen} setActiveScreen={(s) => goTo(s as Screen)} />

          <main className={`flex-1 overflow-y-auto ${activeScreen === 'chat' ? '' : 'pb-20 lg:pb-6'}`}>
            {renderScreen()}
          </main>
        </div>
      </div>

      {/* Mobile Navigation */}
      <MobileNav activeScreen={activeScreen} setActiveScreen={(s) => goTo(s as Screen)} />
    </div>
  );
}
