import { useState, useRef, useEffect } from 'react';
import {
  Sparkles, Send, Mic, Paperclip, ChevronRight,
  BarChart3, FileText, TrendingUp, Brain, Copy, ThumbsUp
} from 'lucide-react';

interface ChatMessage {
  role: string;
  text: string;
  time: string;
  suggestions?: string[];
  chart?: { type: string; title: string };
}

const initialMessages = [
  {
    role: 'ai',
    text: "Hello Sarah! 👋 I've analyzed all 4 of your uploaded files. I have full context of your Q4 sales data, customer records, financial statements, and HR analytics. What would you like to explore?",
    time: '10:32 AM',
    suggestions: [],
  },
  {
    role: 'user',
    text: 'What was our best performing product last quarter?',
    time: '10:33 AM',
  },
  {
    role: 'ai',
    text: "Based on your Q4 data, **Analytics Pro** was your highest-growth product with **35% QoQ growth** and $4.2M in quarterly revenue — up from $3.1M in Q3.\n\nHere's the breakdown:\n\n• Analytics Pro: +35% QoQ ($4.2M)\n• API Services: +29% QoQ ($3.1M)\n• Enterprise Suite: +23% QoQ ($5.9M)\n• SaaS Platform: +26% QoQ ($7.8M)\n\nAnalytics Pro's growth was driven primarily by SMB upsells — 78% of upgrades came from accounts under $10K ARR.",
    time: '10:33 AM',
    chart: { type: 'bar', title: 'Product Revenue Q4 2024' },
    suggestions: ['Why did Analytics Pro grow so fast?', 'Show me top customers by product', 'Generate product forecast'],
  },
  {
    role: 'user',
    text: 'Generate a Q2 sales forecast for me',
    time: '10:35 AM',
  },
  {
    role: 'ai',
    text: "Based on your historical data and current pipeline, here's the Q2 2025 revenue forecast:\n\n📈 **Base Case:** $29.8M (+20.6% YoY)\n🚀 **Bull Case:** $34.1M (+38.3% YoY)\n📉 **Bear Case:** $26.2M (+6.1% YoY)\n\n**Key assumptions:**\n• APAC expansion adds $1.8M incremental\n• Enterprise churn stabilizes at 2.5%\n• 3 new AEs fully ramped by April\n\n**Confidence level:** 84% (high — based on 3 years of training data)",
    time: '10:36 AM',
    chart: { type: 'forecast', title: 'Q2 2025 Revenue Forecast' },
    suggestions: ['What assumptions drive the bull case?', 'Export this as PDF', 'Create forecast presentation'],
  },
];

const quickPrompts = [
  { icon: BarChart3, text: 'Summarize all KPIs' },
  { icon: TrendingUp, text: 'Show revenue trends' },
  { icon: FileText, text: 'Draft executive report' },
  { icon: Brain, text: 'Predict churn risk' },
];

export default function ChatScreen() {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [messages, setMessages] = useState<any[]>(initialMessages);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSend = (text?: string) => {
    const msg = text || input;
    if (!msg.trim()) return;
    setMessages(prev => [...prev, { role: 'user', text: msg, time: 'Now' }]);
    setInput('');
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [...prev, {
        role: 'ai',
        text: "Great question! I'm analyzing your data now. Based on your uploaded files, I can see several interesting patterns. The data suggests a strong correlation between your seasonal campaigns and revenue spikes. Would you like me to generate a detailed breakdown?",
        time: 'Now',
        suggestions: ['Yes, show breakdown', 'Compare to industry benchmarks', 'Export this insight'],
      }]);
    }, 1800);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-64px)]">
      {/* Context Banner */}
      <div className="px-6 py-3 border-b border-slate-700/30" style={{ background: 'rgba(99,102,241,0.05)' }}>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-2 text-slate-400">
            <Brain className="w-3.5 h-3.5 text-purple-400" />
            <span>AI context:</span>
          </div>
          {['Q4 Sales Report.xlsx', 'Customer Data.csv', 'Financial Statements.pdf', 'HR Analytics.docx'].map((f) => (
            <span key={f} className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800/60 border border-slate-700/30 text-slate-400">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400"></span>
              {f}
            </span>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
        {messages.map((msg, i) => (
          <div key={i} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
            {msg.role === 'ai' && (
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center flex-shrink-0 mt-1 glow-purple">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
            )}
            {msg.role === 'user' && (
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-slate-600 to-slate-500 flex items-center justify-center flex-shrink-0 mt-1 text-sm font-bold text-white">
                S
              </div>
            )}

            <div className={`max-w-2xl space-y-3 ${msg.role === 'user' ? 'items-end flex flex-col' : ''}`}>
              <div
                className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'text-white rounded-tr-sm'
                    : 'bg-slate-800/80 text-slate-300 border border-slate-700/30 rounded-tl-sm'
                }`}
                style={msg.role === 'user' ? { background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' } : {}}
              >
                {msg.text.split('\n').map((line: string, j: number) => (
                  <div key={j} className={line === '' ? 'mt-2' : ''}>
                    {line.includes('**') ? (
                      <span dangerouslySetInnerHTML={{ __html: line.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white font-bold">$1</strong>') }} />
                    ) : (
                      <span>{line}</span>
                    )}
                  </div>
                ))}
              </div>

              {/* Chart Placeholder */}
              {(msg as any).chart && (
                <div className="w-full bg-slate-800/60 border border-slate-700/30 rounded-xl p-4">
                  <div className="text-xs font-bold text-slate-400 mb-3 flex items-center gap-2">
                    <BarChart3 className="w-3.5 h-3.5 text-indigo-400" />
                    {(msg as any).chart.title}
                  </div>
                  <div className="h-20 flex items-end justify-around gap-2">
                    {[65, 58, 80, 72, 88, 76, 95].map((h, j) => (
                      <div key={j} className="flex-1 rounded-t" style={{ height: `${h}%`, background: 'linear-gradient(to top, #6366f1, #8b5cf6)', opacity: 0.6 + (j / 7) * 0.4 }}></div>
                    ))}
                  </div>
                  <div className="mt-2 flex justify-between text-xs text-slate-600">
                    {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'].map(m => <span key={m}>{m}</span>)}
                  </div>
                </div>
              )}

              {/* Suggestions */}
              {(msg as any).suggestions?.length > 0 && msg.role === 'ai' && (
                <div className="flex flex-wrap gap-2">
                  {(msg as any).suggestions.map((s: string, j: number) => (
                    <button
                      key={j}
                      onClick={() => handleSend(s)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-indigo-300 border border-indigo-500/30 bg-indigo-500/10 hover:bg-indigo-500/20 transition-all"
                    >
                      {s}
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  ))}
                </div>
              )}

              {/* Feedback */}
              {msg.role === 'ai' && (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-600">{msg.time}</span>
                  <button className="p-1 rounded hover:bg-slate-700/50 transition-all" title="Copy">
                    <Copy className="w-3 h-3 text-slate-600 hover:text-slate-400" />
                  </button>
                  <button className="p-1 rounded hover:bg-slate-700/50 transition-all" title="Like">
                    <ThumbsUp className="w-3 h-3 text-slate-600 hover:text-green-400" />
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-4">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div className="bg-slate-800/80 border border-slate-700/30 rounded-2xl rounded-tl-sm px-4 py-3">
              <div className="flex gap-1.5 items-center">
                <div className="flex gap-1">
                  {[0, 1, 2].map((i) => (
                    <div key={i} className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: `${i * 0.2}s` }}></div>
                  ))}
                </div>
                <span className="text-xs text-slate-500 ml-2">Nexus AI is analyzing your data...</span>
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef}></div>
      </div>

      {/* Quick Prompts */}
      <div className="px-6 py-3 border-t border-slate-700/20">
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          {quickPrompts.map((p, i) => {
            const Icon = p.icon;
            return (
              <button
                key={i}
                onClick={() => handleSend(p.text)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium text-slate-400 bg-slate-800/60 border border-slate-700/30 hover:border-indigo-500/30 hover:text-indigo-300 transition-all whitespace-nowrap flex-shrink-0"
              >
                <Icon className="w-3.5 h-3.5" />
                {p.text}
              </button>
            );
          })}
        </div>
      </div>

      {/* Input */}
      <div className="px-6 pb-6 pt-2">
        <div className="flex items-end gap-3 p-3 rounded-2xl bg-slate-800/80 border border-slate-700/50 hover:border-indigo-500/30 transition-colors focus-within:border-indigo-500/40">
          <button className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-slate-700/50 transition-all flex-shrink-0">
            <Paperclip className="w-4 h-4 text-slate-500 hover:text-indigo-400 transition-colors" />
          </button>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
            placeholder="Ask anything about your data... (e.g. 'Why did churn increase in August?')"
            className="flex-1 bg-transparent text-sm text-white placeholder-slate-500 outline-none resize-none min-h-[36px] max-h-[120px]"
            rows={1}
          />
          <div className="flex items-center gap-2 flex-shrink-0">
            <button className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-slate-700/50 transition-all">
              <Mic className="w-4 h-4 text-slate-500 hover:text-indigo-400 transition-colors" />
            </button>
            <button
              onClick={() => handleSend()}
              disabled={!input.trim()}
              className="w-9 h-9 rounded-xl flex items-center justify-center transition-all disabled:opacity-40"
              style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
            >
              <Send className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>
        <p className="text-xs text-slate-600 text-center mt-2">NexusIQ AI · Powered by GPT-4o + Custom ML · Data processed locally</p>
      </div>
    </div>
  );
}
