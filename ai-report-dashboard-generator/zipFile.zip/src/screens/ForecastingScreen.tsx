import {
  Zap, Brain, Target, Download, RefreshCw
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer
} from 'recharts';

const forecastData = [
  { period: 'Q1 24', actual: 19.2, forecast: null },
  { period: 'Q2 24', actual: 21.3, forecast: null },
  { period: 'Q3 24', actual: 22.8, forecast: null },
  { period: 'Q4 24', actual: 24.7, forecast: null },
  { period: 'Q1 25', actual: null, forecast: 28.2, bull: 31.0, bear: 25.5 },
  { period: 'Q2 25', actual: null, forecast: 30.8, bull: 34.5, bear: 27.1 },
  { period: 'Q3 25', actual: null, forecast: 33.4, bull: 38.2, bear: 28.7 },
  { period: 'Q4 25', actual: null, forecast: 37.1, bull: 43.0, bear: 31.2 },
];

const scenarios = [
  { name: 'Bull Case', revenue: '$43.0M', growth: '+74%', prob: '25%', color: '#10b981', icon: '🚀' },
  { name: 'Base Case', revenue: '$37.1M', growth: '+50%', prob: '55%', color: '#6366f1', icon: '📊' },
  { name: 'Bear Case', revenue: '$31.2M', growth: '+26%', prob: '20%', color: '#f59e0b', icon: '🛡️' },
];

const drivers = [
  { name: 'APAC Expansion', impact: 8.2, type: 'positive', icon: '🌏' },
  { name: 'Analytics Pro Growth', impact: 6.4, type: 'positive', icon: '📈' },
  { name: 'Enterprise Upsell', impact: 4.8, type: 'positive', icon: '💼' },
  { name: 'Enterprise Churn Risk', impact: -3.2, type: 'negative', icon: '⚠️' },
  { name: 'W. Region Gap', impact: -1.8, type: 'negative', icon: '📍' },
  { name: 'Macro Headwinds', impact: -1.2, type: 'negative', icon: '🌐' },
];

export default function ForecastingScreen() {
  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="ai-badge">PREDICTIVE ANALYTICS</div>
            <div className="ai-badge" style={{ background: 'rgba(6,182,212,0.15)', borderColor: 'rgba(6,182,212,0.4)', color: '#67e8f9' }}>
              ML MODEL · 87% ACCURACY
            </div>
          </div>
          <h2 className="text-2xl font-bold text-white">Predictive Forecasting</h2>
          <p className="text-slate-400 text-sm mt-1">AI-powered revenue & growth modeling based on your historical data</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800/60 border border-slate-700/50 text-xs font-medium text-slate-400 hover:border-indigo-500/30 transition-all">
            <RefreshCw className="w-3.5 h-3.5" />
            Recalculate
          </button>
          <button className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white"
            style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}>
            <Download className="w-4 h-4" />
            Export Forecast
          </button>
        </div>
      </div>

      {/* Scenario Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {scenarios.map((s, i) => (
          <div
            key={i}
            className={`glass-card p-5 cursor-pointer transition-all hover:scale-105 ${i === 1 ? 'border-indigo-500/40' : ''}`}
            style={i === 1 ? { boxShadow: '0 0 30px rgba(99,102,241,0.15)' } : {}}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-xl">{s.icon}</span>
                <span className="text-sm font-bold text-white">{s.name}</span>
              </div>
              {i === 1 && <span className="text-xs font-bold text-indigo-400 bg-indigo-500/20 px-2 py-0.5 rounded-full">Most Likely</span>}
            </div>
            <div className="text-3xl font-bold text-white mb-1">{s.revenue}</div>
            <div className="text-sm font-semibold mb-2" style={{ color: s.color }}>
              {s.growth} annual growth
            </div>
            <div className="progress-bar mb-1">
              <div className="h-full rounded-full" style={{ width: s.prob, background: s.color }}></div>
            </div>
            <div className="text-xs text-slate-500">{s.prob} probability</div>
          </div>
        ))}
      </div>

      {/* Main Forecast Chart */}
      <div className="glass-card p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-white">Revenue Forecast 2024–2025</h3>
            <p className="text-xs text-slate-500 mt-0.5">Historical actuals + ML projection · Quarterly · USD Millions</p>
          </div>
          <div className="flex items-center gap-3 text-xs text-slate-500">
            <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-indigo-400 inline-block rounded"></span>Actual</span>
            <span className="flex items-center gap-1"><span className="w-3 h-0.5 border-t-2 border-dashed border-purple-400 inline-block"></span>Forecast</span>
            <span className="flex items-center gap-1"><span className="w-3 h-2 rounded-sm bg-purple-400/20 inline-block"></span>Range</span>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={forecastData}>
            <defs>
              <linearGradient id="actGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4} />
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="bullGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.2} />
                <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(99,102,241,0.08)" />
            <XAxis dataKey="period" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}M`} />
            <Tooltip
              contentStyle={{ background: 'rgba(15,23,42,0.95)', border: '1px solid rgba(99,102,241,0.3)', borderRadius: '8px', fontSize: '12px' }}
            />
            <Area type="monotone" dataKey="bull" name="Bull Case" stroke="transparent" fill="url(#bullGrad)" connectNulls={false} />
            <Area type="monotone" dataKey="actual" name="Actual Revenue" stroke="#6366f1" strokeWidth={2.5} fill="url(#actGrad)" connectNulls={false} dot={{ fill: '#6366f1', r: 4, strokeWidth: 0 }} />
            <Area type="monotone" dataKey="forecast" name="Forecast" stroke="#a78bfa" strokeWidth={2} strokeDasharray="6 3" fill="transparent" connectNulls={false} dot={{ fill: '#a78bfa', r: 4, strokeWidth: 0 }} />
          </AreaChart>
        </ResponsiveContainer>

        {/* Reference line label */}
        <div className="flex items-center justify-center mt-2">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20">
            <div className="w-1.5 h-1.5 rounded-full bg-indigo-400"></div>
            <span className="text-xs text-indigo-400 font-medium">AI Forecast begins Q1 2025</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Growth Drivers */}
        <div className="glass-card p-5">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
            <Target className="w-4 h-4 text-indigo-400" />
            Forecast Drivers (Impact on Revenue)
          </h3>
          <div className="space-y-3">
            {drivers.map((d, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="text-base flex-shrink-0">{d.icon}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-slate-300">{d.name}</span>
                    <span className={`text-xs font-bold ${d.type === 'positive' ? 'text-green-400' : 'text-red-400'}`}>
                      {d.type === 'positive' ? '+' : ''}${d.impact}M
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-800/80 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${(Math.abs(d.impact) / 8.2) * 100}%`,
                        background: d.type === 'positive'
                          ? 'linear-gradient(90deg, #10b981, #34d399)'
                          : 'linear-gradient(90deg, #ef4444, #f87171)',
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 pt-4 border-t border-slate-700/30 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Net Impact</span>
            <span className="text-sm font-bold text-green-400">+$13.2M incremental ARR</span>
          </div>
        </div>

        {/* AI Model Info */}
        <div className="space-y-4">
          <div className="glass-card p-5">
            <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
              <Brain className="w-4 h-4 text-purple-400" />
              AI Model Details
            </h3>
            <div className="space-y-3">
              {[
                { label: 'Algorithm', value: 'XGBoost + LSTM Ensemble' },
                { label: 'Training Data', value: '36 months of actuals' },
                { label: 'Features Used', value: '48 variables' },
                { label: 'Accuracy (MAPE)', value: '4.2% (Excellent)' },
                { label: 'Confidence Interval', value: '87% (2σ)' },
                { label: 'Last Trained', value: 'Dec 15, 2024' },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between">
                  <span className="text-xs text-slate-500">{item.label}</span>
                  <span className="text-xs font-semibold text-slate-300 font-mono">{item.value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-5">
            <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <Zap className="w-4 h-4 text-cyan-400" />
              Key Assumptions
            </h3>
            <div className="space-y-2">
              {[
                'APAC team of 3 AEs hired by Q1',
                'Enterprise churn stabilizes at ≤2.5%',
                'Analytics Pro grows at 30% QoQ',
                'No major competitive disruptions',
                'USD/EUR rate stays within ±5%',
              ].map((a, i) => (
                <div key={i} className="flex items-center gap-2 text-xs text-slate-400">
                  <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 flex-shrink-0"></div>
                  {a}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
