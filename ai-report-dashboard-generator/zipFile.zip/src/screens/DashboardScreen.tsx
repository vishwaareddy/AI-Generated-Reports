import {
  TrendingUp, TrendingDown, Users, DollarSign, ShoppingCart,
  Activity, Filter, Download, RefreshCw, Maximize2, ChevronDown,
  AlertCircle, Sparkles, BarChart3, ArrowUpRight, Globe, Zap
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, Line,
  PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid,
  PolarAngleAxis
} from 'recharts';

const revenueData = [
  { month: 'Jan', revenue: 18.2, target: 17.0, expenses: 11.1 },
  { month: 'Feb', revenue: 19.8, target: 18.5, expenses: 11.8 },
  { month: 'Mar', revenue: 21.1, target: 19.0, expenses: 12.3 },
  { month: 'Apr', revenue: 20.4, target: 20.0, expenses: 12.0 },
  { month: 'May', revenue: 22.7, target: 21.0, expenses: 13.1 },
  { month: 'Jun', revenue: 23.9, target: 22.0, expenses: 13.8 },
  { month: 'Jul', revenue: 22.1, target: 22.5, expenses: 13.2 },
  { month: 'Aug', revenue: 24.3, target: 23.0, expenses: 14.1 },
  { month: 'Sep', revenue: 25.8, target: 23.5, expenses: 14.8 },
  { month: 'Oct', revenue: 24.7, target: 24.0, expenses: 14.2 },
  { month: 'Nov', revenue: 26.4, target: 24.5, expenses: 15.1 },
  { month: 'Dec', revenue: 28.1, target: 25.0, expenses: 15.9 },
];

const salesByRegion = [
  { region: 'North America', value: 42, amount: '$10.4M', color: '#6366f1' },
  { region: 'Europe', value: 28, amount: '$6.9M', color: '#8b5cf6' },
  { region: 'Asia Pacific', value: 18, amount: '$4.4M', color: '#06b6d4' },
  { region: 'Latin America', value: 8, amount: '$2.0M', color: '#10b981' },
  { region: 'Others', value: 4, amount: '$1.0M', color: '#f59e0b' },
];

const productData = [
  { name: 'SaaS Platform', q3: 6.2, q4: 7.8, growth: '+26%' },
  { name: 'Enterprise Suite', q3: 4.8, q4: 5.9, growth: '+23%' },
  { name: 'Analytics Pro', q3: 3.1, q4: 4.2, growth: '+35%' },
  { name: 'API Services', q3: 2.4, q4: 3.1, growth: '+29%' },
  { name: 'Consulting', q3: 2.0, q4: 2.2, growth: '+10%' },
  { name: 'Support Plans', q3: 1.4, q4: 1.5, growth: '+7%' },
];

const performanceData = [
  { subject: 'Revenue', A: 92, fullMark: 100 },
  { subject: 'Growth', A: 78, fullMark: 100 },
  { subject: 'Retention', A: 88, fullMark: 100 },
  { subject: 'NPS', A: 72, fullMark: 100 },
  { subject: 'Efficiency', A: 85, fullMark: 100 },
  { subject: 'Pipeline', A: 68, fullMark: 100 },
];

const metrics = [
  {
    label: 'Total Revenue', value: '$24.7M', change: '+18.3%', trend: 'up',
    sub: 'vs $20.9M last year', icon: DollarSign, color: 'indigo',
    sparkData: [14, 17, 15, 19, 18, 21, 22, 25],
  },
  {
    label: 'Active Customers', value: '12,847', change: '+8.4%', trend: 'up',
    sub: '892 new this quarter', icon: Users, color: 'purple',
    sparkData: [9, 10, 10.5, 11, 11.5, 12, 12.4, 12.8],
  },
  {
    label: 'Avg Deal Size', value: '$18,420', change: '+12.7%', trend: 'up',
    sub: 'Enterprise accounts ↑', icon: ShoppingCart, color: 'cyan',
    sparkData: [14, 15, 15.5, 16, 17, 17.5, 18, 18.4],
  },
  {
    label: 'Churn Rate', value: '2.1%', change: '-0.8pp', trend: 'up',
    sub: 'Below 3% industry avg', icon: Activity, color: 'green',
    sparkData: [3.2, 3.0, 2.9, 2.8, 2.6, 2.4, 2.2, 2.1],
  },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="glass-card p-3 border border-indigo-500/20">
        <p className="text-xs font-bold text-white mb-1">{label}</p>
        {payload.map((p: any, i: number) => (
          <p key={i} className="text-xs" style={{ color: p.color }}>
            {p.name}: ${p.value}M
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function DashboardScreen() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="ai-badge">STEP 3 OF 4</div>
            <div className="ai-badge" style={{ background: 'rgba(16,185,129,0.15)', borderColor: 'rgba(16,185,129,0.4)', color: '#34d399' }}>
              AUTO-GENERATED
            </div>
            <div className="text-xs text-slate-500 flex items-center gap-1">
              <RefreshCw className="w-3 h-3" />
              Live · Updated 2 min ago
            </div>
          </div>
          <h2 className="text-2xl font-bold text-white">Executive Dashboard</h2>
          <p className="text-slate-400 text-sm mt-1">Acme Corporation · Q4 2024 · All Business Units</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800/60 border border-slate-700/50 text-xs font-medium text-slate-400 hover:text-white hover:border-indigo-500/30 transition-all">
            <Filter className="w-3.5 h-3.5" />
            Filters
            <ChevronDown className="w-3 h-3" />
          </button>
          <button className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800/60 border border-slate-700/50 text-xs font-medium text-slate-400 hover:text-white hover:border-indigo-500/30 transition-all">
            <Download className="w-3.5 h-3.5" />
            Export
          </button>
          <button className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold text-white"
            style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}>
            <Sparkles className="w-3.5 h-3.5" />
            AI Report
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((m, i) => {
          const Icon = m.icon;
          const colors: Record<string, { bg: string; border: string; text: string; icon: string }> = {
            indigo: { bg: 'rgba(99,102,241,0.1)', border: 'rgba(99,102,241,0.2)', text: '#818cf8', icon: 'rgba(99,102,241,0.2)' },
            purple: { bg: 'rgba(139,92,246,0.1)', border: 'rgba(139,92,246,0.2)', text: '#a78bfa', icon: 'rgba(139,92,246,0.2)' },
            cyan: { bg: 'rgba(6,182,212,0.1)', border: 'rgba(6,182,212,0.2)', text: '#67e8f9', icon: 'rgba(6,182,212,0.2)' },
            green: { bg: 'rgba(16,185,129,0.1)', border: 'rgba(16,185,129,0.2)', text: '#34d399', icon: 'rgba(16,185,129,0.2)' },
          };
          const c = colors[m.color];
          return (
            <div
              key={i}
              className="metric-card rounded-2xl p-5 relative overflow-hidden cursor-pointer"
              style={{ background: c.bg, border: `1px solid ${c.border}` }}
            >
              <div className="absolute top-0 right-0 w-24 h-24 rounded-full opacity-5 -translate-y-6 translate-x-6"
                style={{ background: c.text }}></div>
              <div className="flex items-start justify-between mb-4">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: c.icon }}>
                  <Icon className="w-4.5 h-4.5" style={{ width: '18px', height: '18px', color: c.text }} />
                </div>
                <div className={`flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-lg ${m.trend === 'up' ? 'text-green-400 bg-green-400/10' : 'text-red-400 bg-red-400/10'}`}>
                  {m.trend === 'up' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {m.change}
                </div>
              </div>
              <div className="text-2xl font-bold text-white mb-1">{m.value}</div>
              <div className="text-xs font-semibold mb-1" style={{ color: c.text }}>{m.label}</div>
              <div className="text-xs text-slate-500">{m.sub}</div>

              {/* Mini sparkline */}
              <div className="mt-3 h-8 flex items-end gap-0.5">
                {m.sparkData.map((v, j) => {
                  const max = Math.max(...m.sparkData);
                  const min = Math.min(...m.sparkData);
                  const h = ((v - min) / (max - min)) * 100;
                  return (
                    <div
                      key={j}
                      className="flex-1 rounded-sm transition-all"
                      style={{ height: `${Math.max(h, 10)}%`, background: c.text, opacity: 0.4 + (j / m.sparkData.length) * 0.6 }}
                    ></div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 glass-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white">Revenue vs Target vs Expenses</h3>
              <p className="text-xs text-slate-500 mt-0.5">12-month trend · USD Millions</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-3 text-xs text-slate-500">
                <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-indigo-400 inline-block rounded"></span>Revenue</span>
                <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-purple-400 inline-block rounded border-dashed" style={{ borderTop: '2px dashed #a78bfa' }}></span>Target</span>
                <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-cyan-400 inline-block rounded"></span>Expenses</span>
              </div>
              <Maximize2 className="w-3.5 h-3.5 text-slate-600 cursor-pointer hover:text-indigo-400" />
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="expGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(99,102,241,0.08)" />
              <XAxis dataKey="month" tick={{ fill: '#64748b', fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#64748b', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}M`} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="revenue" name="Revenue" stroke="#6366f1" strokeWidth={2} fill="url(#revGrad)" />
              <Line type="monotone" dataKey="target" name="Target" stroke="#a78bfa" strokeWidth={1.5} strokeDasharray="5 3" dot={false} />
              <Area type="monotone" dataKey="expenses" name="Expenses" stroke="#06b6d4" strokeWidth={1.5} fill="url(#expGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Regional Breakdown */}
        <div className="glass-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white">Revenue by Region</h3>
              <p className="text-xs text-slate-500">Q4 2024</p>
            </div>
            <Globe className="w-4 h-4 text-indigo-400" />
          </div>
          <ResponsiveContainer width="100%" height={130}>
            <PieChart>
              <Pie
                data={salesByRegion}
                cx="50%"
                cy="50%"
                innerRadius={38}
                outerRadius={58}
                paddingAngle={3}
                dataKey="value"
              >
                {salesByRegion.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value: any) => [`${value}%`, 'Share']} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {salesByRegion.map((r, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: r.color }}></div>
                <span className="text-xs text-slate-400 flex-1">{r.region}</span>
                <span className="text-xs font-bold text-white">{r.amount}</span>
                <span className="text-xs text-slate-500">{r.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Product Performance */}
        <div className="lg:col-span-2 glass-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white">Product Revenue Q3 vs Q4</h3>
              <p className="text-xs text-slate-500">USD Millions · All products</p>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-indigo-500 inline-block"></span>Q3</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-purple-400 inline-block"></span>Q4</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={productData} barSize={16}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(99,102,241,0.08)" horizontal={true} vertical={false} />
              <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#64748b', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}M`} />
              <Tooltip formatter={(v: any) => [`$${v}M`]} contentStyle={{ background: 'rgba(15,23,42,0.95)', border: '1px solid rgba(99,102,241,0.3)', borderRadius: '8px' }} />
              <Bar dataKey="q3" name="Q3" fill="#6366f1" radius={[4, 4, 0, 0]} fillOpacity={0.6} />
              <Bar dataKey="q4" name="Q4" fill="#a78bfa" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Business Radar */}
        <div className="glass-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white">Business Health Score</h3>
              <p className="text-xs text-slate-500">AI-scored metrics</p>
            </div>
            <div className="text-2xl font-bold gradient-text">84</div>
          </div>
          <ResponsiveContainer width="100%" height={190}>
            <RadarChart data={performanceData}>
              <PolarGrid stroke="rgba(99,102,241,0.15)" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 9 }} />
              <Radar name="Score" dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.2} strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI Insights Bar */}
      <div className="glass-card p-4">
        <div className="flex items-center gap-3 mb-3">
          <Sparkles className="w-4 h-4 text-purple-400" />
          <h3 className="text-sm font-bold text-white">AI-Generated Insights</h3>
          <span className="ai-badge">4 insights found</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { icon: '💡', color: 'indigo', text: 'Analytics Pro grew 35% — highest product growth this quarter', action: 'Double investment' },
            { icon: '⚠️', color: 'orange', text: 'Western region 23% below Q4 target — requires immediate attention', action: 'View details' },
            { icon: '🚀', color: 'green', text: 'Enterprise deals up 29% — expand sales team in this segment', action: 'See forecast' },
            { icon: '📊', color: 'cyan', text: 'APAC pipeline strong — projected Q1 growth of 41%', action: 'View pipeline' },
          ].map((ins, i) => (
            <div key={i} className="insight-card p-3 cursor-pointer group">
              <div className="flex items-start gap-2 mb-2">
                <span className="text-lg">{ins.icon}</span>
                <p className="text-xs text-slate-400 leading-relaxed flex-1">{ins.text}</p>
              </div>
              <button className="text-xs font-semibold text-indigo-400 flex items-center gap-1 group-hover:gap-2 transition-all">
                {ins.action} <ArrowUpRight className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom: Top Performers + Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Top sales reps */}
        <div className="glass-card p-5">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-indigo-400" />
            Top Sales Performers
          </h3>
          <div className="space-y-3">
            {[
              { name: 'Marcus Williams', region: 'NA-East', revenue: '$2.8M', quota: 108, avatar: 'M' },
              { name: 'Priya Sharma', region: 'APAC', revenue: '$2.4M', quota: 96, avatar: 'P' },
              { name: 'James O\'Brien', region: 'EMEA', revenue: '$2.1M', quota: 94, avatar: 'J' },
              { name: 'Elena Kowalski', region: 'NA-West', revenue: '$1.9M', quota: 91, avatar: 'E' },
            ].map((rep, i) => (
              <div key={i} className="flex items-center gap-3 p-2 rounded-xl hover:bg-slate-800/30 transition-all">
                <div className="text-sm font-bold text-slate-500 w-5">#{i + 1}</div>
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">
                  {rep.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-white">{rep.name}</div>
                  <div className="text-xs text-slate-500">{rep.region}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-white">{rep.revenue}</div>
                  <div className={`text-xs font-semibold ${rep.quota >= 100 ? 'text-green-400' : 'text-yellow-400'}`}>
                    {rep.quota}% quota
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="glass-card p-5">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
            <Activity className="w-4 h-4 text-cyan-400" />
            AI Activity Feed
          </h3>
          <div className="space-y-3">
            {[
              { time: '2m ago', event: 'Anomaly detected in Q4 expense data — review recommended', type: 'alert', icon: AlertCircle },
              { time: '18m ago', event: 'Revenue forecast model updated with latest data', type: 'info', icon: Zap },
              { time: '1h ago', event: 'Executive PDF report generated and ready for download', type: 'success', icon: ArrowUpRight },
              { time: '2h ago', event: 'New customer data synced from Salesforce (847 records)', type: 'info', icon: RefreshCw },
              { time: '3h ago', event: 'Q3 vs Q4 comparison analysis completed — 23 insights found', type: 'success', icon: Sparkles },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <div key={i} className="flex items-start gap-3 text-xs">
                  <div className={`w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${
                    item.type === 'alert' ? 'bg-orange-500/20 text-orange-400' :
                    item.type === 'success' ? 'bg-green-500/20 text-green-400' :
                    'bg-indigo-500/20 text-indigo-400'
                  }`}>
                    <Icon style={{ width: '12px', height: '12px' }} />
                  </div>
                  <div className="flex-1">
                    <p className="text-slate-300 leading-relaxed">{item.event}</p>
                    <span className="text-slate-600 mt-0.5 block">{item.time}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
