import { useState, useEffect } from 'react';
import {
  Brain, CheckCircle, Loader2, Sparkles, TrendingUp,
  ChevronRight, Zap, ArrowRight, Target
} from 'lucide-react';

interface AnalysisScreenProps {
  onComplete: () => void;
}

const analysisSteps = [
  { id: 1, label: 'File ingestion & format detection', status: 'done', time: '0.3s', detail: '4 files · 17.4 MB total' },
  { id: 2, label: 'Smart data cleaning & deduplication', status: 'done', time: '1.2s', detail: '2,847 rows cleaned · 143 duplicates removed' },
  { id: 3, label: 'Schema inference & type casting', status: 'done', time: '0.8s', detail: '34 columns mapped · 7 types detected' },
  { id: 4, label: 'NLP document summarization', status: 'done', time: '2.1s', detail: '148-page PDF → 12 key takeaways' },
  { id: 5, label: 'Statistical analysis & outlier detection', status: 'processing', time: '...', detail: 'Running ANOVA + IQR analysis' },
  { id: 6, label: 'KPI extraction & metric calculation', status: 'queued', time: '', detail: '' },
  { id: 7, label: 'Trend & pattern recognition', status: 'queued', time: '', detail: '' },
  { id: 8, label: 'Predictive model selection & training', status: 'queued', time: '', detail: '' },
  { id: 9, label: 'Visualization generation', status: 'queued', time: '', detail: '' },
  { id: 10, label: 'Executive report assembly', status: 'queued', time: '', detail: '' },
];

const kpis = [
  { label: 'Total Revenue', value: '$24.7M', change: '+18.3%', trend: 'up', color: 'text-green-400' },
  { label: 'Net Profit Margin', value: '31.4%', change: '+4.2pp', trend: 'up', color: 'text-green-400' },
  { label: 'Customer Churn', value: '2.1%', change: '-0.8pp', trend: 'up', color: 'text-green-400' },
  { label: 'CAC', value: '$142', change: '-12.1%', trend: 'down', color: 'text-green-400' },
  { label: 'NPS Score', value: '72', change: '+8pts', trend: 'up', color: 'text-green-400' },
  { label: 'MoM Growth', value: '6.8%', change: '+1.4pp', trend: 'up', color: 'text-green-400' },
];

const insights = [
  { type: 'opportunity', icon: '💡', text: 'Q3 Western Region underperformed by 23% — reallocating budget could yield +$2.1M annually', priority: 'HIGH' },
  { type: 'warning', icon: '⚠️', text: 'Customer churn spike detected in Enterprise tier (Aug-Sep) — correlates with pricing change', priority: 'CRITICAL' },
  { type: 'trend', icon: '📈', text: 'Mobile sales channel grew 47% YoY — accelerate investment for maximum ROI', priority: 'MED' },
  { type: 'prediction', icon: '🔮', text: 'Q1 2025 revenue forecast: $8.2M–$9.1M (87% confidence interval)', priority: 'INFO' },
];

const chatMessages = [
  { role: 'ai', text: 'I\'ve finished analyzing your Q4 Sales Report. Here\'s what stands out most...' },
  { role: 'ai', text: 'Revenue grew 18.3% YoY to $24.7M. The strongest segment was SaaS subscriptions at $14.2M (+31%). Western region needs attention — 23% below target.' },
  { role: 'user', text: 'What caused the churn spike in August?' },
  { role: 'ai', text: 'Cross-referencing your customer data with pricing history: Enterprise tier churn jumped from 1.3% → 4.7% in August, 2 weeks after the 18% price increase. I\'d recommend a grandfathering strategy for accounts > 24 months.' },
];

export default function AnalysisScreen({ onComplete }: AnalysisScreenProps) {
  const [progress, setProgress] = useState(47);
  const [chatInput, setChatInput] = useState('');

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(p => Math.min(p + 0.5, 73));
    }, 200);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="animate-fade-in-up flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="ai-badge">STEP 2 OF 4</div>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/30">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
              <span className="text-xs font-semibold text-green-400">AI ENGINE ACTIVE</span>
            </div>
          </div>
          <h2 className="text-3xl font-bold text-white mb-1">Generating Intelligence...</h2>
          <p className="text-slate-400">AI is extracting insights, detecting patterns, and building your executive dashboard</p>
        </div>
        <button
          onClick={onComplete}
          className="hidden md:flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-white transition-all hover:scale-105"
          style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', boxShadow: '0 4px 15px rgba(99,102,241,0.3)' }}
        >
          View Dashboard
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Analysis Steps */}
        <div className="lg:col-span-2 space-y-4">
          {/* Progress */}
          <div className="glass-card p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center">
                  <Brain className="w-5 h-5 text-indigo-400 animate-pulse" />
                </div>
                <div>
                  <div className="text-sm font-bold text-white">Analysis Pipeline</div>
                  <div className="text-xs text-slate-500">4 files · GPT-4o + ML models</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold gradient-text">{Math.round(progress)}%</div>
                <div className="text-xs text-slate-500">Complete</div>
              </div>
            </div>
            <div className="h-3 rounded-full bg-slate-800/80 overflow-hidden mb-2 border border-slate-700/30">
              <div
                className="h-full rounded-full transition-all duration-300"
                style={{
                  width: `${progress}%`,
                  background: 'linear-gradient(90deg, #6366f1, #8b5cf6, #06b6d4)',
                  boxShadow: '0 0 15px rgba(99,102,241,0.5)'
                }}
              ></div>
            </div>
            <div className="flex justify-between text-xs text-slate-500">
              <span>Est. 23 seconds remaining</span>
              <span>17.4 MB processed</span>
            </div>
          </div>

          {/* Steps list */}
          <div className="glass-card p-5">
            <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-indigo-400" />
              Processing Pipeline
            </h3>
            <div className="space-y-2">
              {analysisSteps.map((step) => (
                <div
                  key={step.id}
                  className={`flex items-center gap-3 p-3 rounded-xl transition-all ${
                    step.status === 'processing' ? 'bg-indigo-500/10 border border-indigo-500/20' :
                    step.status === 'done' ? 'bg-slate-800/30' : 'opacity-40'
                  }`}
                >
                  <div className="flex-shrink-0">
                    {step.status === 'done' && <CheckCircle className="w-4 h-4 text-green-400" />}
                    {step.status === 'processing' && <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />}
                    {step.status === 'queued' && <div className="w-4 h-4 rounded-full border-2 border-slate-600"></div>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className={`text-sm font-medium ${step.status === 'done' ? 'text-slate-300' : step.status === 'processing' ? 'text-white' : 'text-slate-500'}`}>
                      {step.label}
                    </div>
                    {step.detail && (
                      <div className="text-xs text-slate-500 mt-0.5">{step.detail}</div>
                    )}
                  </div>
                  {step.time && step.status === 'done' && (
                    <span className="text-xs text-green-400 font-mono flex-shrink-0">{step.time}</span>
                  )}
                  {step.status === 'processing' && (
                    <div className="flex gap-1 flex-shrink-0">
                      {[0, 1, 2].map((i) => (
                        <div
                          key={i}
                          className="w-1 h-4 rounded-full bg-indigo-400 animate-wave"
                          style={{ animationDelay: `${i * 0.15}s` }}
                        />
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* KPI Preview */}
          <div className="glass-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Target className="w-4 h-4 text-indigo-400" />
                KPIs Extracted (Preview)
              </h3>
              <span className="ai-badge">LIVE</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {kpis.map((kpi, i) => (
                <div key={i} className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/30">
                  <div className="text-xs text-slate-500 mb-1">{kpi.label}</div>
                  <div className="text-lg font-bold text-white">{kpi.value}</div>
                  <div className={`text-xs font-semibold ${kpi.color} flex items-center gap-1 mt-0.5`}>
                    <TrendingUp className="w-3 h-3" />
                    {kpi.change} vs LY
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: AI Chat */}
        <div className="space-y-4">
          {/* AI Assistant */}
          <div className="glass-card p-5 h-fit">
            <div className="flex items-center gap-3 mb-4">
              <div className="relative">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-400 rounded-full border-2 border-slate-900"></div>
              </div>
              <div>
                <div className="text-sm font-bold text-white">Nexus AI</div>
                <div className="text-xs text-green-400 flex items-center gap-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></div>
                  Analyzing your data
                </div>
              </div>
            </div>

            <div className="space-y-3 mb-4 max-h-80 overflow-y-auto">
              {chatMessages.map((msg, i) => (
                <div key={i} className={`flex gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                  {msg.role === 'ai' && (
                    <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Sparkles className="w-3 h-3 text-white" />
                    </div>
                  )}
                  <div
                    className={`text-xs p-3 rounded-xl max-w-xs ${
                      msg.role === 'ai'
                        ? 'bg-slate-800/80 text-slate-300 border border-slate-700/30'
                        : 'text-white'
                    }`}
                    style={msg.role === 'user' ? { background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' } : {}}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
              <div className="flex gap-2">
                <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-3 h-3 text-white" />
                </div>
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/30">
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <div key={i} className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: `${i * 0.2}s` }}></div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Ask about your data..."
                className="flex-1 bg-slate-800/60 border border-slate-700/50 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500/50"
              />
              <button className="w-8 h-8 rounded-xl bg-indigo-500 flex items-center justify-center hover:bg-indigo-400 transition-colors">
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>

          {/* AI Insights Preview */}
          <div className="glass-card p-5">
            <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <Brain className="w-4 h-4 text-purple-400" />
              AI Discoveries
            </h3>
            <div className="space-y-2.5">
              {insights.map((ins, i) => (
                <div key={i} className="insight-card p-3">
                  <div className="flex items-start gap-2">
                    <span className="text-base flex-shrink-0">{ins.icon}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${
                          ins.priority === 'CRITICAL' ? 'bg-red-500/20 text-red-400' :
                          ins.priority === 'HIGH' ? 'bg-orange-500/20 text-orange-400' :
                          ins.priority === 'MED' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-blue-500/20 text-blue-400'
                        }`}>{ins.priority}</span>
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed">{ins.text}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
