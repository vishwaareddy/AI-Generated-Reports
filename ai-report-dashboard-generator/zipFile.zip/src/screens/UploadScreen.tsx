import { useState, useRef } from 'react';
import {
  Upload, FileSpreadsheet, FileText, Database, File,
  CheckCircle, Loader2, Zap, Shield, CloudUpload,
  Globe, Link2, Sparkles, ArrowRight, X
} from 'lucide-react';

interface UploadScreenProps {
  onComplete: () => void;
}

const fileTypes = [
  { icon: '📊', label: 'Excel', ext: '.xlsx', color: 'from-green-600 to-green-500' },
  { icon: '📋', label: 'CSV', ext: '.csv', color: 'from-blue-600 to-blue-500' },
  { icon: '📄', label: 'PDF', ext: '.pdf', color: 'from-red-600 to-red-500' },
  { icon: '📝', label: 'Word', ext: '.docx', color: 'from-sky-600 to-sky-500' },
  { icon: '📊', label: 'PowerPoint', ext: '.pptx', color: 'from-orange-600 to-orange-500' },
  { icon: '🗄️', label: 'SQL', ext: '.sql', color: 'from-violet-600 to-violet-500' },
  { icon: '{}', label: 'JSON', ext: '.json', color: 'from-yellow-600 to-yellow-500' },
  { icon: '📗', label: 'Google Sheets', ext: 'gsheet', color: 'from-emerald-600 to-emerald-500' },
];

const integrations = [
  { name: 'Salesforce', color: '#00A1E0', icon: '☁️' },
  { name: 'SAP', color: '#0078D4', icon: '⚙️' },
  { name: 'QuickBooks', color: '#2CA01C', icon: '💚' },
  { name: 'Google Sheets', color: '#34A853', icon: '📗' },
  { name: 'HubSpot', color: '#FF7A59', icon: '🔶' },
  { name: 'Snowflake', color: '#29B5E8', icon: '❄️' },
];

const uploadedFiles = [
  { name: 'Q4_Sales_Report.xlsx', size: '2.4 MB', type: 'Excel', status: 'done', progress: 100 },
  { name: 'Customer_Data_2024.csv', size: '8.1 MB', type: 'CSV', status: 'done', progress: 100 },
  { name: 'Financial_Statements.pdf', size: '5.7 MB', type: 'PDF', status: 'processing', progress: 67 },
  { name: 'HR_Analytics.docx', size: '1.2 MB', type: 'Word', status: 'queued', progress: 0 },
];

export default function UploadScreen({ onComplete }: UploadScreenProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [activeTab, setActiveTab] = useState<'upload' | 'connect' | 'url'>('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="animate-fade-in-up">
        <div className="flex items-center gap-3 mb-2">
          <div className="ai-badge">STEP 1 OF 4</div>
          <div className="ai-badge" style={{ background: 'rgba(6,182,212,0.15)', borderColor: 'rgba(6,182,212,0.4)', color: '#67e8f9' }}>SMART OCR ENABLED</div>
        </div>
        <h2 className="text-3xl font-bold text-white mb-2">Upload Any Business Data</h2>
        <p className="text-slate-400 text-base">Our AI ingests 50+ file formats, cleans data automatically, and extracts structured intelligence in seconds.</p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-800/60 rounded-xl w-fit border border-slate-700/50">
        {(['upload', 'connect', 'url'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all capitalize ${
              activeTab === tab ? 'tab-active shadow-lg' : 'text-slate-400 hover:text-white'
            }`}
          >
            {tab === 'upload' ? '📂 Upload File' : tab === 'connect' ? '🔌 Connect App' : '🔗 Paste URL'}
          </button>
        ))}
      </div>

      {activeTab === 'upload' && (
        <>
          {/* Drop Zone */}
          <div
            className={`upload-zone rounded-2xl p-12 text-center cursor-pointer relative overflow-hidden transition-all ${isDragging ? 'drag-over' : ''}`}
            style={{ background: isDragging ? 'rgba(99,102,241,0.08)' : 'rgba(15,23,42,0.6)' }}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => { e.preventDefault(); setIsDragging(false); }}
            onClick={() => fileInputRef.current?.click()}
          >
            {/* Animated background lines */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              {[...Array(6)].map((_, i) => (
                <div
                  key={i}
                  className="absolute h-px w-full opacity-20"
                  style={{
                    top: `${(i + 1) * 16}%`,
                    background: 'linear-gradient(90deg, transparent, rgba(99,102,241,0.6), transparent)',
                    animation: `shimmer ${2 + i * 0.3}s infinite`,
                    animationDelay: `${i * 0.4}s`,
                  }}
                />
              ))}
            </div>

            <div className="relative z-10">
              <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/30 flex items-center justify-center animate-float">
                <CloudUpload className="w-10 h-10 text-indigo-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Drop files here or click to browse</h3>
              <p className="text-slate-400 mb-6">Supports Excel, CSV, PDF, Word, PowerPoint, SQL, JSON, Google Sheets, and 40+ more formats</p>

              <div className="flex flex-wrap justify-center gap-3 mb-6">
                {fileTypes.map((ft) => (
                  <div
                    key={ft.label}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold text-white transition-transform hover:scale-105"
                    style={{ background: `linear-gradient(135deg, rgba(${ft.color.includes('green') ? '22,163,74' : ft.color.includes('blue') ? '37,99,235' : ft.color.includes('red') ? '220,38,38' : ft.color.includes('sky') ? '2,132,199' : ft.color.includes('orange') ? '234,88,12' : ft.color.includes('violet') ? '124,58,237' : ft.color.includes('yellow') ? '202,138,4' : '5,150,105'},0.2), rgba(${ft.color.includes('green') ? '22,163,74' : ft.color.includes('blue') ? '37,99,235' : ft.color.includes('red') ? '220,38,38' : ft.color.includes('sky') ? '2,132,199' : ft.color.includes('orange') ? '234,88,12' : ft.color.includes('violet') ? '124,58,237' : ft.color.includes('yellow') ? '202,138,4' : '5,150,105'},0.1))`, border: '1px solid rgba(255,255,255,0.1)' }}
                  >
                    <span>{ft.icon}</span>
                    <span>{ft.label}</span>
                  </div>
                ))}
              </div>

              <button className="px-6 py-3 rounded-xl font-semibold text-white text-sm transition-all hover:scale-105"
                style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', boxShadow: '0 8px 25px rgba(99,102,241,0.4)' }}>
                <Upload className="w-4 h-4 inline mr-2" />
                Choose Files
              </button>
              <p className="text-xs text-slate-600 mt-3">Max 500MB per file · Enterprise: Unlimited</p>
            </div>
            <input ref={fileInputRef} type="file" multiple className="hidden" />
          </div>

          {/* Uploaded Files */}
          <div className="glass-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-400" />
                Uploaded Files
                <span className="bg-indigo-500/20 text-indigo-400 text-xs px-2 py-0.5 rounded-full">4 files</span>
              </h3>
              <button
                onClick={onComplete}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white transition-all hover:scale-105"
                style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', boxShadow: '0 4px 15px rgba(99,102,241,0.3)' }}
              >
                <Sparkles className="w-4 h-4" />
                Analyze All
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              {uploadedFiles.map((file, i) => (
                <div key={i} className="flex items-center gap-4 p-3 rounded-xl bg-slate-800/50 border border-slate-700/30 hover:border-indigo-500/20 transition-all group">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-lg flex-shrink-0 ${
                    file.type === 'Excel' ? 'bg-green-500/20' :
                    file.type === 'CSV' ? 'bg-blue-500/20' :
                    file.type === 'PDF' ? 'bg-red-500/20' : 'bg-sky-500/20'
                  }`}>
                    {file.type === 'Excel' ? '📊' : file.type === 'CSV' ? '📋' : file.type === 'PDF' ? '📄' : '📝'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-semibold text-white truncate">{file.name}</span>
                      <div className="flex items-center gap-2 ml-2 flex-shrink-0">
                        <span className="text-xs text-slate-500">{file.size}</span>
                        {file.status === 'done' && <CheckCircle className="w-4 h-4 text-green-400" />}
                        {file.status === 'processing' && <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />}
                        {file.status === 'queued' && <div className="w-2 h-2 rounded-full bg-slate-500"></div>}
                        <X className="w-4 h-4 text-slate-600 hover:text-red-400 cursor-pointer opacity-0 group-hover:opacity-100 transition-all" />
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="progress-bar flex-1">
                        <div className="progress-fill" style={{ width: `${file.progress}%` }}></div>
                      </div>
                      <span className={`text-xs font-medium flex-shrink-0 ${
                        file.status === 'done' ? 'text-green-400' :
                        file.status === 'processing' ? 'text-indigo-400' : 'text-slate-500'
                      }`}>
                        {file.status === 'done' ? 'Complete' : file.status === 'processing' ? `${file.progress}% · Parsing...` : 'Queued'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* AI Features */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { icon: '🧹', title: 'Auto Data Cleaning', desc: 'Removes duplicates, fixes nulls' },
              { icon: '🔍', title: 'Smart OCR', desc: 'Extracts text from scanned PDFs' },
              { icon: '🌐', title: 'Multi-language', desc: '50+ languages supported' },
              { icon: '🔐', title: 'AES-256 Encryption', desc: 'Zero-knowledge processing' },
            ].map((f, i) => (
              <div key={i} className="glass-card p-4 text-center">
                <div className="text-2xl mb-2">{f.icon}</div>
                <div className="text-xs font-bold text-white mb-1">{f.title}</div>
                <div className="text-xs text-slate-500">{f.desc}</div>
              </div>
            ))}
          </div>
        </>
      )}

      {activeTab === 'connect' && (
        <div className="glass-card p-6">
          <h3 className="text-lg font-bold text-white mb-2">Connect Your Apps</h3>
          <p className="text-slate-400 text-sm mb-6">Sync live data from your business tools in real-time</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {integrations.map((int, i) => (
              <button
                key={i}
                className="flex items-center gap-3 p-4 rounded-xl bg-slate-800/50 border border-slate-700/30 hover:border-indigo-500/30 hover:bg-slate-800/80 transition-all group text-left"
              >
                <span className="text-2xl">{int.icon}</span>
                <div>
                  <div className="text-sm font-semibold text-white group-hover:text-indigo-300 transition-colors">{int.name}</div>
                  <div className="text-xs text-slate-500">Click to connect</div>
                </div>
                <Link2 className="w-4 h-4 text-slate-600 group-hover:text-indigo-400 ml-auto transition-colors" />
              </button>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'url' && (
        <div className="glass-card p-6">
          <h3 className="text-lg font-bold text-white mb-2">Import from URL</h3>
          <p className="text-slate-400 text-sm mb-6">Paste a link to a Google Sheet, public dataset, or API endpoint</p>
          <div className="flex gap-3">
            <div className="flex-1 flex items-center gap-3 bg-slate-800/60 border border-slate-700/50 rounded-xl px-4 py-3 hover:border-indigo-500/40 transition-colors">
              <Globe className="w-4 h-4 text-slate-500" />
              <input
                type="url"
                placeholder="https://docs.google.com/spreadsheets/..."
                className="bg-transparent text-sm text-white placeholder-slate-500 outline-none flex-1"
              />
            </div>
            <button className="px-6 py-3 rounded-xl font-semibold text-white text-sm"
              style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}>
              Import
            </button>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            {['Google Sheets', 'Airtable', 'Public API', 'GitHub CSV', 'Data.gov'].map((s) => (
              <span key={s} className="text-xs px-3 py-1.5 rounded-lg bg-slate-800/60 text-slate-400 border border-slate-700/30 cursor-pointer hover:text-indigo-400 hover:border-indigo-500/30 transition-all">{s}</span>
            ))}
          </div>
        </div>
      )}

      {/* Security badges */}
      <div className="flex flex-wrap gap-3 items-center">
        {['SOC 2 Type II', 'ISO 27001', 'GDPR Compliant', 'HIPAA Ready', 'Zero-Knowledge'].map((b) => (
          <div key={b} className="security-badge">
            <Shield style={{ width: '10px', height: '10px' }} />
            {b}
          </div>
        ))}
      </div>
    </div>
  );
}
