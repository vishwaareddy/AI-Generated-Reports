import {
  Sparkles, Target,
  Brain, ArrowUpRight, ChevronRight, Zap
} from 'lucide-react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, AreaChart, Area
} from 'recharts';

const forecastData = [
  { month: 'Oct', actual: 24.7, forecast: null },
  { month: 'Nov', actual: 26.4, forecast: null },
  { month: 'Dec', actual: 28.1, forecast: null },
  { month: 'Jan', actual: null, forecast: 27.8, upper: 29.1, lower: 26.5 },
  { month: 'Feb', actual: null, forecast: 29.4, upper: 31.2, lower: 27.6 },
  { month: 'Mar', actual: null, forecast: 31.1, upper: 33.5, lower: 28.7 },
  { month: 'Apr', actual: null, forecast: 32.8, upper: 36.0, lower: 29.6 },
];

const insights = [
  {
    type: 'critical', priority: 1, icon: '🚨',
    title: 'Enterprise Churn Crisis Detected',
    desc: 'Churn rate in Enterprise tier spiked from 1.3% to 4.7% in August, correlating with the 18% price increase. 147 accounts (ARR: $4.2M) are at risk of cancellation in Q1.',
    action: 'Launch retention campaign',
    impact: '$4.2M ARR at risk',
    confidence: 94,
    tags: ['Churn', 'Enterprise', 'Urgent'],
    data: [1.3, 1.2, 1.4, 1.3, 4.7, 4.2, 3.8],
  },
  {
    type: 'opportunity', priority: 2, icon: '💡',
    title: 'Analytics Pro: Highest Growth Product',
    desc: 'Analytics Pro grew 35% QoQ — fastest of all product lines. Customer cohort analysis shows 78% of upgrades came from SMB accounts. Upsell potential: $2.4M ARR untapped.',
    action: 'Scale upsell campaign',
    impact: '+$2.4M ARR potential',
    confidence: 87,
    tags: ['Product', 'Growth', 'Upsell'],
    data: [3.1, 3.4, 3.6, 3.9, 4.1, 4.2, 4.6],
  },
  {
    type: 'trend', priority: 3, icon: '📈',
    title: 'APAC Pipeline Strength',
    desc: 'Asia-Pacific pipeline has grown 41% QoQ with average deal size up 23%. Current capacity constraint: only 2 AEs covering a $400M TAM market.',
    action: 'Hire 3 APAC AEs',
    impact: '+$3.1M ARR (12mo)',
    confidence: 82,
    tags: ['APAC', 'Pipeline', 'Hiring'],
    data: [2.1, 2.3, 2.8, 3.1, 3.5, 3.9, 4.4],
  },
  {
    type: 'anomaly', priority: 4, icon: '⚠️',
    title: 'Western Region Underperformance',
    desc: 'NA-West finished 23% below Q4 quota. Root cause analysis points to 2 factors: rep turnover (3 AEs left in Q3) and competitive displacement by Vendor X in mid-market segment.',
    action: 'Competitive war room',
    impact: '-$2.1M vs target',
    confidence: 91,
    tags: ['Sales', 'Region', 'Risk'],
    data: [3.2, 3.0, 2.8, 2.4, 2.2, 2.0, 1.9],
  },
];

const aiSuggestions = [
  { text: 'Generate churn prevention playbook', icon: '🎯' },
  { text: 'Model APAC expansion ROI scenarios', icon: '📊' },
  { text: 'Compare pricing elasticity analysis', icon: '💰' },
  { text: 'Forecast Enterprise cohort behavior', icon: '🔮' },
];

export default function InsightsScreen() {
  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="ai-badge">AI INSIGHTS ENGINE</div>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30">
              <Sparkles className="w-3 h-3 text-purple-400" />
              <span className="text-xs font-semibold text-purple-400">23 insights found</span>
            </div>
          </div>
          <h2 className="text-2xl font-bold text-white">AI-Generated Insights</h2>
          <p className="text-slate-400 text-sm mt-1">Pattern recognition + NLP analysis across all uploaded datasets</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white"
          style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}>
          <Brain className="w-4 h-4" />
          Deep Analysis
        </button>
      </div>

      {/* Score Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Overall Health Score', value: '84/100', icon: '❤️', color: 'green', sub: 'Above industry avg' },
          { label: 'Growth Trajectory', value: '+18.3%', icon: '🚀', color: 'indigo', sub: '4th straight quarter' },
          { label: 'Risk Index', value: 'MEDIUM', icon: '⚡', color: 'orange', sub: '3 critical issues' },
          { label: 'AI Confidence', value: '91%', icon: '🧠', color: 'purple', sub: 'High data quality' },
        ].map((card, i) => (
          <div key={i} className={`glass-card p-4 ${
            card.color === 'green' ? 'border-green-500/20' :
            card.color === 'indigo' ? 'border-indigo-500/20' :
            card.color === 'orange' ? 'border-orange-500/20' : 'border-purple-500/20'
          }`}>
            <div className="text-2xl mb-2">{card.icon}</div>
            <div className="text-lg font-bold text-white">{card.value}</div>
            <div className={`text-xs font-semibold mb-1 ${
              card.color === 'green' ? 'text-green-400' :
              card.color === 'indigo' ? 'text-indigo-400' :
              card.color === 'orange' ? 'text-orange-400' : 'text-purple-400'
            }`}>{card.label}</div>
            <div className="text-xs text-slate-500">{card.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Insights List */}
        <div className="lg:col-span-2 space-y-4">
          {insights.map((insight, i) => (
            <div
              key={i}
              className={`glass-card p-5 transition-all hover:border-opacity-60 cursor-pointer group ${
                insight.type === 'critical' ? 'border-red-500/25 hover:border-red-500/40' :
                insight.type === 'opportunity' ? 'border-indigo-500/25 hover:border-indigo-500/40' :
                insight.type === 'trend' ? 'border-green-500/25 hover:border-green-500/40' :
                'border-orange-500/25 hover:border-orange-500/40'
              }`}
            >
              <div className="flex items-start gap-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0 ${
                  insight.type === 'critical' ? 'bg-red-500/15' :
                  insight.type === 'opportunity' ? 'bg-indigo-500/15' :
                  insight.type === 'trend' ? 'bg-green-500/15' : 'bg-orange-500/15'
                }`}>
                  {insight.icon}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                          insight.type === 'critical' ? 'bg-red-500/20 text-red-400' :
                          insight.type === 'opportunity' ? 'bg-indigo-500/20 text-indigo-400' :
                          insight.type === 'trend' ? 'bg-green-500/20 text-green-400' :
                          'bg-orange-500/20 text-orange-400'
                        }`}>
                          #{insight.priority} · {insight.type.toUpperCase()}
                        </span>
                        <div className="flex items-center gap-1 text-xs text-slate-500">
                          <Brain className="w-3 h-3" />
                          {insight.confidence}% confidence
                        </div>
                      </div>
                      <h3 className="text-sm font-bold text-white mb-1 group-hover:text-indigo-300 transition-colors">{insight.title}</h3>
                    </div>
                    <div className={`text-xs font-bold px-2 py-1 rounded-lg flex-shrink-0 ${
                      insight.impact.includes('+') ? 'text-green-400 bg-green-400/10' : 'text-red-400 bg-red-400/10'
                    }`}>
                      {insight.impact}
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed mb-3">{insight.desc}</p>

                  {/* Mini chart */}
                  <div className="h-12 mb-3">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={insight.data.map((v, j) => ({ x: j, v }))}>
                        <Line
                          type="monotone"
                          dataKey="v"
                          stroke={
                            insight.type === 'critical' ? '#f87171' :
                            insight.type === 'opportunity' ? '#818cf8' :
                            insight.type === 'trend' ? '#34d399' : '#fb923c'
                          }
                          strokeWidth={2}
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex flex-wrap gap-1">
                      {insight.tags.map((t) => (
                        <span key={t} className="ai-badge">{t}</span>
                      ))}
                    </div>
                    <button className="flex items-center gap-1.5 text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition-colors">
                      {insight.action} <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Right Panel */}
        <div className="space-y-4">
          {/* Forecast */}
          <div className="glass-card p-5">
            <h3 className="text-sm font-bold text-white mb-1 flex items-center gap-2">
              <Zap className="w-4 h-4 text-cyan-400" />
              Revenue Forecast
            </h3>
            <p className="text-xs text-slate-500 mb-4">Q1 2025 · 87% confidence</p>
            <ResponsiveContainer width="100%" height={150}>
              <AreaChart data={forecastData}>
                <defs>
                  <linearGradient id="fcGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(99,102,241,0.08)" />
                <XAxis dataKey="month" tick={{ fill: '#64748b', fontSize: 9 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#64748b', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}M`} />
                <Tooltip contentStyle={{ background: 'rgba(15,23,42,0.95)', border: '1px solid rgba(99,102,241,0.3)', borderRadius: '8px', fontSize: '11px' }} />
                <Area type="monotone" dataKey="actual" name="Actual" stroke="#6366f1" strokeWidth={2} fill="url(#fcGrad)" connectNulls={false} />
                <Line type="monotone" dataKey="forecast" name="Forecast" stroke="#a78bfa" strokeWidth={1.5} strokeDasharray="5 3" dot={false} connectNulls={false} />
              </AreaChart>
            </ResponsiveContainer>
            <div className="mt-3 p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
              <div className="text-sm font-bold text-white">$8.2M – $9.1M</div>
              <div className="text-xs text-slate-400">Q1 2025 Revenue Range</div>
            </div>
          </div>

          {/* AI Quick Actions */}
          <div className="glass-card p-4">
            <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              Ask AI About This Data
            </h3>
            <div className="space-y-2">
              {aiSuggestions.map((s, i) => (
                <button
                  key={i}
                  className="w-full text-left flex items-center gap-3 p-3 rounded-xl bg-slate-800/50 border border-slate-700/30 hover:border-indigo-500/30 hover:bg-slate-800/80 transition-all group"
                >
                  <span className="text-base">{s.icon}</span>
                  <span className="text-xs text-slate-400 group-hover:text-slate-200 transition-colors flex-1">{s.text}</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-indigo-400 transition-colors" />
                </button>
              ))}
            </div>
          </div>

          {/* Pattern Detection */}
          <div className="glass-card p-4">
            <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <Target className="w-4 h-4 text-indigo-400" />
              Patterns Detected
            </h3>
            <div className="space-y-2.5">
              {[
                { pattern: 'Seasonality', detail: 'Q4 consistently +12% vs Q3', icon: '📅', strength: 89 },
                { pattern: 'Price Elasticity', detail: '>15% increase → churn spike', icon: '💹', strength: 94 },
                { pattern: 'Deal Velocity', detail: 'Enterprise cycles: 47 days avg', icon: '⏱️', strength: 76 },
                { pattern: 'Cohort Retention', detail: '2020 cohort: 91% retention', icon: '👥', strength: 81 },
              ].map((p, i) => (
                <div key={i} className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-800/40">
                  <span className="text-base flex-shrink-0">{p.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-white">{p.pattern}</div>
                    <div className="text-xs text-slate-500">{p.detail}</div>
                  </div>
                  <div className={`text-xs font-bold flex-shrink-0 ${p.strength >= 90 ? 'text-green-400' : p.strength >= 80 ? 'text-indigo-400' : 'text-yellow-400'}`}>
                    {p.strength}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
