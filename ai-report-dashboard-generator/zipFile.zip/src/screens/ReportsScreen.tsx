import {
  FileText, Download, Share2, Sparkles, Eye, Clock,
  CheckCircle, Star, TrendingUp, Users, DollarSign,
  AlertTriangle, ChevronRight, Printer, Mail, Copy,
  BarChart3, PieChart, Brain
} from 'lucide-react';

const reports = [
  {
    id: 1, title: 'Q4 2024 Executive Summary', type: 'Executive Report',
    pages: 24, generated: '2 min ago', status: 'ready',
    tags: ['Revenue', 'KPIs', 'Forecast'], icon: '📊', score: 94,
    desc: 'Comprehensive Q4 performance review with revenue analysis, KPI scorecard, market trends, and Q1 2025 forecasts.',
    highlights: ['$24.7M revenue (+18.3% YoY)', 'Churn at record low 2.1%', '3 critical risk areas identified'],
  },
  {
    id: 2, title: 'Sales Performance Deep Dive', type: 'Sales Report',
    pages: 18, generated: '5 min ago', status: 'ready',
    tags: ['Sales', 'Pipeline', 'Team'], icon: '💰', score: 91,
    desc: 'Detailed sales team performance, pipeline analysis, deal velocity, win/loss ratios, and territory breakdown.',
    highlights: ['Top rep: Marcus Williams $2.8M', 'Win rate improved to 34%', 'APAC pipeline +41% QoQ'],
  },
  {
    id: 3, title: 'Customer Churn Analysis', type: 'Risk Report',
    pages: 12, generated: '8 min ago', status: 'ready',
    tags: ['Churn', 'Risk', 'Retention'], icon: '⚠️', score: 88,
    desc: 'Root cause analysis of Aug-Sep churn spike in Enterprise tier with intervention recommendations.',
    highlights: ['Price increase → churn spike', '147 at-risk accounts identified', 'Grandfathering recommended'],
  },
  {
    id: 4, title: 'Financial P&L Statement', type: 'Financial Report',
    pages: 31, generated: '12 min ago', status: 'ready',
    tags: ['Finance', 'P&L', 'EBITDA'], icon: '📈', score: 97,
    desc: 'Auto-generated P&L from uploaded financial statements with variance analysis and board-ready formatting.',
    highlights: ['EBITDA: $7.8M (31.4% margin)', 'OpEx under budget by 4.2%', 'Cash runway: 28 months'],
  },
  {
    id: 5, title: 'HR & Headcount Analytics', type: 'HR Report',
    pages: 15, generated: '15 min ago', status: 'generating',
    tags: ['HR', 'Headcount', 'Attrition'], icon: '👥', score: null,
    desc: 'Workforce analytics including headcount trends, attrition analysis, compensation benchmarking.',
    highlights: [],
  },
];

const swotData = {
  strengths: ['Market-leading NPS of 72', 'SaaS ARR growing 31% YoY', 'Strong enterprise customer base (89% retention)'],
  weaknesses: ['Western region underperforming by 23%', 'High Enterprise CAC ($310)', 'Limited APAC sales capacity'],
  opportunities: ['APAC market expansion ($400M TAM)', 'Analytics Pro upsell opportunity', 'New API monetization tier'],
  threats: ['Competitor pricing pressure (3 players)', 'Macro headwinds in H1 2025', 'Enterprise churn risk post-pricing'],
};

export default function ReportsScreen() {
  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="ai-badge">STEP 4 OF 4</div>
            <div className="ai-badge" style={{ background: 'rgba(16,185,129,0.15)', borderColor: 'rgba(16,185,129,0.4)', color: '#34d399' }}>5 REPORTS READY</div>
          </div>
          <h2 className="text-2xl font-bold text-white">AI-Generated Reports</h2>
          <p className="text-slate-400 text-sm mt-1">Board-ready documents generated from your uploaded data</p>
        </div>
        <button className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-white"
          style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', boxShadow: '0 4px 15px rgba(99,102,241,0.3)' }}>
          <Sparkles className="w-4 h-4" />
          Generate Custom Report
        </button>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { icon: '📋', label: 'One-Click PDF', desc: 'All reports bundled', color: 'indigo' },
          { icon: '📊', label: 'PowerPoint Deck', desc: '12-slide exec deck', color: 'purple' },
          { icon: '📧', label: 'Email to Board', desc: 'Auto-scheduled send', color: 'cyan' },
          { icon: '🔗', label: 'Share Link', desc: 'Secure viewer link', color: 'green' },
        ].map((a, i) => (
          <button key={i} className="glass-card p-4 text-left hover:scale-105 transition-all group cursor-pointer">
            <div className="text-2xl mb-2">{a.icon}</div>
            <div className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">{a.label}</div>
            <div className="text-xs text-slate-500">{a.desc}</div>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Reports List */}
        <div className="lg:col-span-2 space-y-4">
          {reports.map((report) => (
            <div key={report.id} className="glass-card p-5 hover:border-indigo-500/30 transition-all group cursor-pointer">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-slate-800/80 border border-slate-700/30 flex items-center justify-center text-2xl flex-shrink-0">
                  {report.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3 mb-1">
                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">{report.title}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-slate-500">{report.type}</span>
                        <span className="text-slate-700">·</span>
                        <span className="text-xs text-slate-500">{report.pages} pages</span>
                        <span className="text-slate-700">·</span>
                        <Clock className="w-3 h-3 text-slate-600" />
                        <span className="text-xs text-slate-500">{report.generated}</span>
                      </div>
                    </div>
                    {report.score && (
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                        <span className="text-sm font-bold text-yellow-400">{report.score}</span>
                      </div>
                    )}
                  </div>

                  <p className="text-xs text-slate-400 mb-3 leading-relaxed">{report.desc}</p>

                  {report.highlights.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-3">
                      {report.highlights.map((h, i) => (
                        <span key={i} className="text-xs px-2 py-1 rounded-lg bg-slate-800/60 text-slate-400 border border-slate-700/30 flex items-center gap-1">
                          <CheckCircle className="w-3 h-3 text-green-400" />
                          {h}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {report.tags.map((t) => (
                      <span key={t} className="ai-badge">{t}</span>
                    ))}
                  </div>

                  <div className="flex items-center gap-2">
                    {report.status === 'ready' ? (
                      <>
                        <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white transition-all"
                          style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}>
                          <Eye className="w-3.5 h-3.5" /> Preview
                        </button>
                        <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 bg-slate-800/60 border border-slate-700/30 hover:border-indigo-500/30 transition-all">
                          <Download className="w-3.5 h-3.5" /> PDF
                        </button>
                        <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 bg-slate-800/60 border border-slate-700/30 hover:border-indigo-500/30 transition-all">
                          <Share2 className="w-3.5 h-3.5" /> Share
                        </button>
                        <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 bg-slate-800/60 border border-slate-700/30 hover:border-indigo-500/30 transition-all">
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                      </>
                    ) : (
                      <div className="flex items-center gap-2 text-xs text-indigo-400">
                        <div className="w-4 h-4 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin"></div>
                        Generating report...
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Right Panel */}
        <div className="space-y-4">
          {/* SWOT Analysis */}
          <div className="glass-card p-5">
            <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
              <Brain className="w-4 h-4 text-purple-400" />
              AI-Generated SWOT
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {[
                { key: 'strengths', label: 'Strengths', color: 'green', icon: '💪', items: swotData.strengths },
                { key: 'weaknesses', label: 'Weaknesses', color: 'red', icon: '⚠️', items: swotData.weaknesses },
                { key: 'opportunities', label: 'Opportunities', color: 'blue', icon: '🚀', items: swotData.opportunities },
                { key: 'threats', label: 'Threats', color: 'orange', icon: '🛡️', items: swotData.threats },
              ].map((s) => (
                <div
                  key={s.key}
                  className={`p-3 rounded-xl ${
                    s.color === 'green' ? 'bg-green-500/10 border border-green-500/20' :
                    s.color === 'red' ? 'bg-red-500/10 border border-red-500/20' :
                    s.color === 'blue' ? 'bg-blue-500/10 border border-blue-500/20' :
                    'bg-orange-500/10 border border-orange-500/20'
                  }`}
                >
                  <div className={`text-xs font-bold mb-2 flex items-center gap-1 ${
                    s.color === 'green' ? 'text-green-400' :
                    s.color === 'red' ? 'text-red-400' :
                    s.color === 'blue' ? 'text-blue-400' : 'text-orange-400'
                  }`}>
                    <span>{s.icon}</span> {s.label}
                  </div>
                  <ul className="space-y-1.5">
                    {s.items.map((item, i) => (
                      <li key={i} className="text-xs text-slate-400 leading-relaxed flex gap-1">
                        <ChevronRight className="w-3 h-3 flex-shrink-0 mt-0.5 text-slate-600" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Business Recommendations */}
          <div className="glass-card p-5">
            <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              AI Recommendations
            </h3>
            <div className="space-y-3">
              {[
                { priority: 1, action: 'Launch Enterprise grandfathering program to stem churn', impact: '+$1.2M ARR', urgency: 'URGENT' },
                { priority: 2, action: 'Expand APAC sales team by 3 reps (projected ROI 4.2x)', impact: '+$3.1M ARR', urgency: 'HIGH' },
                { priority: 3, action: 'Accelerate Analytics Pro marketing — highest growth product', impact: '+$2.4M ARR', urgency: 'MED' },
              ].map((rec) => (
                <div key={rec.priority} className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/30 hover:border-indigo-500/20 transition-all">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-400 text-xs font-bold flex items-center justify-center">{rec.priority}</span>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                      rec.urgency === 'URGENT' ? 'bg-red-500/20 text-red-400' :
                      rec.urgency === 'HIGH' ? 'bg-orange-500/20 text-orange-400' :
                      'bg-yellow-500/20 text-yellow-400'
                    }`}>{rec.urgency}</span>
                    <span className="text-xs font-bold text-green-400 ml-auto">{rec.impact}</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">{rec.action}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Export Options */}
          <div className="glass-card p-4">
            <h3 className="text-sm font-bold text-white mb-3">Export & Share</h3>
            <div className="space-y-2">
              {[
                { icon: Download, label: 'Download All as PDF', sub: '5 reports · 100 pages' },
                { icon: BarChart3, label: 'Export as PowerPoint', sub: 'Auto-generated deck' },
                { icon: Mail, label: 'Email to Stakeholders', sub: 'Schedule distribution' },
                { icon: Copy, label: 'Copy Share Link', sub: 'Viewer-only access' },
              ].map((opt, i) => {
                const Icon = opt.icon;
                return (
                  <button key={i} className="w-full flex items-center gap-3 p-2.5 rounded-xl bg-slate-800/50 border border-slate-700/30 hover:border-indigo-500/20 hover:bg-slate-800/80 transition-all text-left group">
                    <div className="w-7 h-7 rounded-lg bg-indigo-500/15 flex items-center justify-center">
                      <Icon className="w-3.5 h-3.5 text-indigo-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-white group-hover:text-indigo-300 transition-colors">{opt.label}</div>
                      <div className="text-xs text-slate-500">{opt.sub}</div>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-indigo-400 transition-colors" />
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
