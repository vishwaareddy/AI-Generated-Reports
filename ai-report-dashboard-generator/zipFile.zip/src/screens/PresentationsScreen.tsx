import { useState } from 'react';
import {
  Presentation, Play, Download, Share2, Sparkles, ChevronLeft,
  ChevronRight, Maximize2, LayoutTemplate, Palette, Clock, Star
} from 'lucide-react';

const slides = [
  {
    id: 1, title: 'Q4 2024 Business Review', type: 'title',
    content: 'Acme Corporation · Executive Briefing · December 2024',
    bg: 'from-indigo-900 via-purple-900 to-slate-900',
  },
  {
    id: 2, title: 'Executive Summary', type: 'summary',
    metrics: [
      { label: 'Revenue', value: '$24.7M', change: '↑18.3%' },
      { label: 'Profit Margin', value: '31.4%', change: '↑4.2pp' },
      { label: 'Customers', value: '12,847', change: '↑8.4%' },
      { label: 'NPS Score', value: '72', change: '↑8pts' },
    ],
    bg: 'from-slate-900 to-slate-800',
  },
  {
    id: 3, title: 'Revenue Growth Story', type: 'chart',
    content: 'Record $24.7M revenue — 4th consecutive quarter of growth',
    bg: 'from-indigo-950 to-slate-900',
  },
  {
    id: 4, title: 'Key Risks & Opportunities', type: 'swot',
    content: 'Enterprise churn spike requires immediate action',
    bg: 'from-slate-900 via-purple-950 to-slate-900',
  },
  {
    id: 5, title: '2025 Strategic Roadmap', type: 'roadmap',
    content: 'Three-pillar growth strategy: Expansion · Retention · Innovation',
    bg: 'from-cyan-950 to-slate-900',
  },
  {
    id: 6, title: 'Financial Forecast Q1 2025', type: 'forecast',
    content: 'Projected revenue: $8.2M–$9.1M (87% confidence)',
    bg: 'from-slate-900 to-indigo-950',
  },
];

const templates = [
  { name: 'Executive Board', slides: 12, style: 'Dark Enterprise', active: true },
  { name: 'Investor Pitch', slides: 15, style: 'Bold & Modern', active: false },
  { name: 'Team Briefing', slides: 8, style: 'Clean Light', active: false },
  { name: 'Sales QBR', slides: 20, style: 'Data-Forward', active: false },
];

export default function PresentationsScreen() {
  const [activeSlide, setActiveSlide] = useState(0);

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="ai-badge">AI PRESENTATIONS</div>
            <div className="ai-badge" style={{ background: 'rgba(245,158,11,0.15)', borderColor: 'rgba(245,158,11,0.4)', color: '#fbbf24' }}>
              6 SLIDES READY
            </div>
          </div>
          <h2 className="text-2xl font-bold text-white">Presentation Builder</h2>
          <p className="text-slate-400 text-sm mt-1">AI-generated executive deck from your data · Ready in 8 seconds</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium text-slate-300 bg-slate-800/60 border border-slate-700/50 hover:border-indigo-500/30 transition-all">
            <Play className="w-4 h-4" /> Present
          </button>
          <button className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white"
            style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}>
            <Download className="w-4 h-4" /> Export .PPTX
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Slide Thumbnails */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Slides</h3>
          <div className="space-y-2">
            {slides.map((slide, i) => (
              <button
                key={slide.id}
                onClick={() => setActiveSlide(i)}
                className={`w-full text-left rounded-xl overflow-hidden border-2 transition-all ${
                  activeSlide === i ? 'border-indigo-500 shadow-lg shadow-indigo-500/20' : 'border-slate-700/50 hover:border-slate-600'
                }`}
              >
                <div
                  className={`h-16 bg-gradient-to-br ${slide.bg} p-3 flex flex-col justify-between`}
                >
                  <div className="text-xs font-bold text-white/80 leading-tight line-clamp-1">{slide.title}</div>
                  <div className="text-xs text-white/40">{i + 1} / {slides.length}</div>
                </div>
              </button>
            ))}
          </div>

          <button className="w-full py-2.5 rounded-xl border-2 border-dashed border-slate-700 text-xs text-slate-500 hover:border-indigo-500/40 hover:text-indigo-400 transition-all flex items-center justify-center gap-1">
            <Sparkles className="w-3.5 h-3.5" />
            Add AI Slide
          </button>
        </div>

        {/* Main Slide Preview */}
        <div className="lg:col-span-2 space-y-4">
          {/* Slide */}
          <div
            className={`relative rounded-2xl overflow-hidden aspect-video bg-gradient-to-br ${slides[activeSlide].bg} border border-slate-700/30`}
            style={{ minHeight: '280px' }}
          >
            {/* Decorative elements */}
            <div className="absolute inset-0 grid-bg opacity-30"></div>
            <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-white/10 flex items-center justify-center">
                  <span className="text-xs text-white font-bold">N</span>
                </div>
                <span className="text-xs text-white/50">NexusIQ</span>
              </div>
              <div className="flex gap-1">
                {slides.map((_, i) => (
                  <div key={i} className={`h-0.5 rounded-full transition-all ${i === activeSlide ? 'w-4 bg-white' : 'w-1.5 bg-white/30'}`}></div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-center h-full p-8">
              {slides[activeSlide].type === 'title' && (
                <div className="text-center">
                  <div className="inline-block px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-semibold mb-4">
                    CONFIDENTIAL · Q4 2024
                  </div>
                  <h2 className="text-3xl font-bold text-white mb-3">{slides[activeSlide].title}</h2>
                  <p className="text-slate-400 text-sm">{slides[activeSlide].content}</p>
                  <div className="mt-6 w-16 h-0.5 bg-gradient-to-r from-indigo-500 to-purple-500 mx-auto"></div>
                </div>
              )}

              {slides[activeSlide].type === 'summary' && (
                <div className="w-full">
                  <h2 className="text-xl font-bold text-white mb-6 text-center">{slides[activeSlide].title}</h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {slides[activeSlide].metrics?.map((m, i) => (
                      <div key={i} className="text-center p-3 rounded-xl bg-white/5 border border-white/10">
                        <div className="text-2xl font-bold text-white mb-1">{m.value}</div>
                        <div className="text-xs text-green-400 font-bold mb-1">{m.change}</div>
                        <div className="text-xs text-slate-400">{m.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {(slides[activeSlide].type === 'chart' || slides[activeSlide].type === 'forecast') && (
                <div className="w-full text-center">
                  <h2 className="text-xl font-bold text-white mb-3">{slides[activeSlide].title}</h2>
                  <p className="text-slate-400 text-sm mb-4">{slides[activeSlide].content}</p>
                  <div className="h-20 flex items-end justify-center gap-2">
                    {[60, 75, 72, 85, 80, 90, 85, 95, 100, 92, 105, 110].map((h, i) => (
                      <div
                        key={i}
                        className="flex-1 rounded-t"
                        style={{
                          height: `${h / 1.2}%`,
                          background: i === 11 ? 'linear-gradient(to top, #6366f1, #8b5cf6)' : 'rgba(99,102,241,0.4)',
                          maxWidth: '20px'
                        }}
                      ></div>
                    ))}
                  </div>
                </div>
              )}

              {slides[activeSlide].type === 'swot' && (
                <div className="w-full">
                  <h2 className="text-xl font-bold text-white mb-4 text-center">{slides[activeSlide].title}</h2>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    {[
                      { label: 'Strengths', color: 'green', items: ['NPS 72 (+8)', 'SaaS ARR +31%'] },
                      { label: 'Weaknesses', color: 'red', items: ['W. Region -23%', 'High Ent. CAC'] },
                      { label: 'Opportunities', color: 'blue', items: ['APAC expansion', 'Analytics upsell'] },
                      { label: 'Threats', color: 'orange', items: ['Pricing pressure', 'Churn risk'] },
                    ].map((s) => (
                      <div key={s.label} className={`p-2 rounded-lg border ${
                        s.color === 'green' ? 'bg-green-500/10 border-green-500/20' :
                        s.color === 'red' ? 'bg-red-500/10 border-red-500/20' :
                        s.color === 'blue' ? 'bg-blue-500/10 border-blue-500/20' :
                        'bg-orange-500/10 border-orange-500/20'
                      }`}>
                        <div className={`font-bold mb-1 ${
                          s.color === 'green' ? 'text-green-400' :
                          s.color === 'red' ? 'text-red-400' :
                          s.color === 'blue' ? 'text-blue-400' : 'text-orange-400'
                        }`}>{s.label}</div>
                        {s.items.map((item, i) => <div key={i} className="text-slate-400">{item}</div>)}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {slides[activeSlide].type === 'roadmap' && (
                <div className="w-full text-center">
                  <h2 className="text-xl font-bold text-white mb-6">{slides[activeSlide].title}</h2>
                  <p className="text-slate-400 text-sm mb-6">{slides[activeSlide].content}</p>
                  <div className="flex items-center justify-center gap-4">
                    {['Q1 2025\nExpansion', 'Q2 2025\nRetention', 'Q3 2025\nInnovation'].map((item, i) => (
                      <div key={i} className="flex items-center gap-4">
                        <div className="text-center">
                          <div className="w-12 h-12 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-xl mb-1 mx-auto">
                            {['🚀', '🛡️', '⚡'][i]}
                          </div>
                          <div className="text-xs text-white font-bold whitespace-pre-line">{item}</div>
                        </div>
                        {i < 2 && <div className="w-8 h-0.5 bg-indigo-500/40"></div>}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Watermark */}
            <div className="absolute bottom-3 right-4 text-xs text-white/20 font-mono">
              NexusIQ · Confidential
            </div>

            {/* Navigation */}
            <button
              onClick={() => setActiveSlide(Math.max(0, activeSlide - 1))}
              className="absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-black/30 border border-white/10 flex items-center justify-center hover:bg-black/50 transition-all"
            >
              <ChevronLeft className="w-4 h-4 text-white" />
            </button>
            <button
              onClick={() => setActiveSlide(Math.min(slides.length - 1, activeSlide + 1))}
              className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-black/30 border border-white/10 flex items-center justify-center hover:bg-black/50 transition-all"
            >
              <ChevronRight className="w-4 h-4 text-white" />
            </button>
          </div>

          {/* Slide Controls */}
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Slide {activeSlide + 1} of {slides.length}</span>
            <div className="flex items-center gap-2">
              <button className="p-2 rounded-lg bg-slate-800/60 border border-slate-700/30 hover:border-indigo-500/30 transition-all">
                <Maximize2 className="w-3.5 h-3.5 text-slate-400" />
              </button>
              <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-indigo-500/20 border border-indigo-500/30">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                AI Improve Slide
              </button>
            </div>
          </div>
        </div>

        {/* Right Panel */}
        <div className="space-y-4">
          {/* Templates */}
          <div className="glass-card p-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
              <LayoutTemplate className="w-3.5 h-3.5" />
              Templates
            </h3>
            <div className="space-y-2">
              {templates.map((t, i) => (
                <button
                  key={i}
                  className={`w-full text-left p-3 rounded-xl transition-all border ${
                    t.active
                      ? 'bg-indigo-500/10 border-indigo-500/30'
                      : 'bg-slate-800/40 border-slate-700/30 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-semibold ${t.active ? 'text-indigo-300' : 'text-slate-300'}`}>{t.name}</span>
                    {t.active && <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">{t.slides} slides · {t.style}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Customize */}
          <div className="glass-card p-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
              <Palette className="w-3.5 h-3.5" />
              Customize
            </h3>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-500 mb-1.5 block">Color Scheme</label>
                <div className="flex gap-2">
                  {['#6366f1', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b'].map((c) => (
                    <div
                      key={c}
                      className="w-6 h-6 rounded-full cursor-pointer border-2 border-transparent hover:border-white/50 transition-all"
                      style={{ background: c }}
                    ></div>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1.5 block">Tone</label>
                <div className="flex gap-1.5">
                  {['Formal', 'Bold', 'Minimal'].map((t) => (
                    <button key={t} className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                      t === 'Formal' ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' : 'bg-slate-800/60 text-slate-400 border border-slate-700/30 hover:border-slate-600'
                    }`}>{t}</button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1.5 block">Logo / Branding</label>
                <button className="w-full py-2 rounded-lg border border-dashed border-slate-700 text-xs text-slate-500 hover:border-indigo-500/40 hover:text-indigo-400 transition-all">
                  + Upload Logo
                </button>
              </div>
            </div>
          </div>

          {/* AI Settings */}
          <div className="glass-card p-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5" />
              AI Generation
            </h3>
            <div className="space-y-2.5">
              {[
                { label: 'Auto-generate charts', on: true },
                { label: 'Include forecasts', on: true },
                { label: 'Add speaker notes', on: true },
                { label: 'Brand voice matching', on: false },
              ].map((opt) => (
                <div key={opt.label} className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">{opt.label}</span>
                  <div className={`w-8 h-4 rounded-full transition-all cursor-pointer ${opt.on ? 'bg-indigo-500' : 'bg-slate-700'}`}>
                    <div className={`w-3 h-3 rounded-full bg-white m-0.5 transition-all ${opt.on ? 'translate-x-4' : ''}`}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
